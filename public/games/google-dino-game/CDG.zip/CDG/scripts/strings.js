var pageData = {
  altGameCommonImage1x:
    "images/default_100_percent/offline/100-olympic-firemedal-sprites.png",
  altGameCommonImage2x:
    "images/default_200_percent/offline/200-olympic-firemedal-sprites.png",
  dinoGameA11yAriaLabel: "",
  dinoGameA11yGameOver: "Game over, your score is $1.",
  dinoGameA11yHighScore: "Your highest score is $1.",
  dinoGameA11yJump: "Jump!",
  dinoGameA11ySpeedToggle: "Start slower",
  dinoGameA11yStartGame: "Game started.",
  enableAltGameMode: false,
  errorCode: "",
  fontfamily: "'Segoe UI', Tahoma, sans-serif",
  fontsize: "75%",
  heading: { hostName: "dino", msg: "Press space to play" },
  iconClass: "icon-offline",
  language: "en",
  textdirection: "ltr",
  title: "chrome://dino/",
};
loadTimeData.data = pageData;
